`timescale 1ns / 1ps
module T2Processor_tbPhase2;
    logic clk;
    logic rstn;

    T2Processor #(
        .FILE_NAME("machine_code_phase2.mem")
    ) dut (
        .clk(clk),
        .rstn(rstn)
    );

    initial begin
        rstn = 0;
        clk  = 0;
        #2 rstn = 1;
    end

    always #5 clk = ~clk;

    initial begin
        #1000 $finish;
    end
endmodule