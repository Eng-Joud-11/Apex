module DataMemory
    #(parameter DATA_WIDTH = 4,
      parameter ADDR_WIDTH = 3)
(
    input  logic clk, rstn,
    input  logic [ADDR_WIDTH-1:0] Address,
    input  logic [DATA_WIDTH-1:0] DataIn,
    input  logic Write,
    output logic [DATA_WIDTH-1:0] DataOut
);
    logic [DATA_WIDTH-1:0] memory [0:(2**ADDR_WIDTH)-1];

    initial begin
        $readmemb("data_init.mem", memory);
    end

    always @(posedge clk or negedge rstn) begin
        if (!rstn)
            $readmemb("data_init.mem", memory);
        else if (Write)
            memory[Address] <= DataIn;
    end

    assign DataOut = memory[Address];
endmodule