module T2Processor
#(parameter DATA_WIDTH = 4,
  parameter ADDR_WIDTH = 4,
  parameter MEM_DEPTH  = 16,
  parameter FILE_NAME  = "machine_code.mem")
(
    input logic clk, rstn
);
    logic [7:0] Instruction;
    logic J, C, D1, D0, Sreg, S;
    logic [2:0] Imm;                             
    logic [DATA_WIDTH-1:0] RoOut;

    Datapath #(DATA_WIDTH, ADDR_WIDTH, MEM_DEPTH, FILE_NAME) DpathInst (
        .clk(clk),
        .rstn(rstn),
        .J(J), .C(C),
        .D0(D0), .D1(D1),
        .Sreg(Sreg),
        .S(S),
        .Imm(Imm),                               
        .Instruction(Instruction),
        .RoOut(RoOut)
    );

    ControlUnit CtrlInst (
        .Instruction(Instruction),
        .J(J), .C(C),
        .D1(D1), .D0(D0),
        .Sreg(Sreg),
        .S(S),
        .Imm(Imm)                                 
    );
endmodule