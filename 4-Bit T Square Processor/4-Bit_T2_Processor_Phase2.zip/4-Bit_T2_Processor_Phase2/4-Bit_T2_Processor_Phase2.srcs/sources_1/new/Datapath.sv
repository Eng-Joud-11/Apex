module Datapath
    #(parameter DATA_WIDTH = 4,
      parameter ADDR_WIDTH = 4,
      parameter MEM_DEPTH  = 16,
      parameter FILE_NAME  = "machine_code.mem")
(
    input  logic clk, rstn,
    input  logic J, C,
    input  logic D0, D1,
    input  logic Sreg,
    input  logic S,
    input  logic [2:0] Imm,
    output logic [7:0] Instruction,
    output logic [DATA_WIDTH-1:0] RoOut
);
    logic [ADDR_WIDTH-1:0] PcOut;
    logic [DATA_WIDTH-1:0] ImmExtended;
    logic EnA, EnB, EnO;
    logic [DATA_WIDTH-1:0] AluOut;
    logic AluCarryOut;
    logic [DATA_WIDTH-1:0] MuxOut;
    logic [DATA_WIDTH-1:0] RaOut, RbOut;
    logic CarryFlag;
    logic Load; 
    logic JOnly, CJump, ZJump; 
    logic MemOp, MemWrite;
    logic ZeroFlagRaw, ZeroFlag;
    logic [DATA_WIDTH-1:0] MemDataOut, FinalMuxOut;                               

    assign ImmExtended = {1'b0, Imm};
    assign MemOp    = C & Sreg;
    assign MemWrite = MemOp & D1 & D0;
    assign JOnly = J & ~C;
    assign CJump = (~J) & C & (~Sreg) & CarryFlag;
    assign ZJump = J & C & ZeroFlag;
    assign Load  = JOnly | CJump | ZJump; 

    ProgramCounter #(ADDR_WIDTH) PcInst (
        .clk(clk), .rstn(rstn),
        .Load(Load),                                
        .D(ImmExtended),                             
        .Q(PcOut)                                    
    );

    InstructionMemory #(MEM_DEPTH, FILE_NAME) ImemInst (
        .Address(PcOut),
        .Instruction(Instruction)
    );

    Decoder2to4 DecInst (
        .D0(D0), .D1(D1),
        .Y0(EnA), .Y1(EnB), .Y2(EnO), .Y3()         
    );

    MUX2to1 #(DATA_WIDTH) MuxInst (
        .In0(AluOut), .In1(ImmExtended),
        .Sel(Sreg), .Out(MuxOut)
    );
    
     DataMemory #(DATA_WIDTH, 3) MemInst (
        .clk(clk), .rstn(rstn),
        .Address(Imm), .DataIn(RaOut),
        .Write(MemWrite), .DataOut(MemDataOut)
    );
    
    MUX2to1 #(DATA_WIDTH) MuxMemInst (
        .In0(MuxOut), .In1(MemDataOut),
        .Sel(MemOp), .Out(FinalMuxOut)
    );

    DataRegisters #(DATA_WIDTH) RaInst (
        .clk(clk), .rstn(rstn), .En(EnA),
        .In(FinalMuxOut), .Out(RaOut)
    );

    DataRegisters #(DATA_WIDTH) RbInst (
        .clk(clk), .rstn(rstn), .En(EnB),
        .In(FinalMuxOut), .Out(RbOut)
    );

    DataRegisters #(DATA_WIDTH) RoInst (
        .clk(clk), .rstn(rstn), .En(EnO),
        .In(RaOut), .Out(RoOut)
    );

    ALU #(DATA_WIDTH) AluInst (
        .A(RaOut), .B(RbOut), .S(S),
        .Out(AluOut), .CarryOut(AluCarryOut) , .Zero(ZeroFlagRaw)
    );

    DataRegisters #(1) CarryDffInst (
        .clk(clk), .rstn(rstn), .En(1'b1 & ~(J & C)),
        .In(AluCarryOut), .Out(CarryFlag) 
    );
    
    DataRegisters #(1) ZeroDffInst (
    .clk(clk), .rstn(rstn), .En(1'b1),   
    .In(ZeroFlagRaw), .Out(ZeroFlag)
);

endmodule