module ControlUnit (
    input  logic [7:0] Instruction,
    output logic J,C,D1, D0,Sreg,S,
    output logic [2:0] Imm
);

    assign J    = Instruction[7];
    assign C    = Instruction[6];
    assign D1   = Instruction[5];
    assign D0   = Instruction[4];
    assign Sreg = Instruction[3];
    assign S    = Instruction[2];
    assign Imm  = Instruction[2:0];

endmodule