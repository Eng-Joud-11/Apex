module InstructionMemory
#(parameter MEM_DEPTH = 16,
  parameter FILE_NAME = "machine_code.mem")
(
    input  logic [$clog2(MEM_DEPTH)-1:0] Address,
    output logic [7:0]                   Instruction
);

    logic [7:0] Imem [0:MEM_DEPTH-1];

    initial begin
        $readmemb(FILE_NAME, Imem);
    end

    assign Instruction = Imem[Address];

endmodule