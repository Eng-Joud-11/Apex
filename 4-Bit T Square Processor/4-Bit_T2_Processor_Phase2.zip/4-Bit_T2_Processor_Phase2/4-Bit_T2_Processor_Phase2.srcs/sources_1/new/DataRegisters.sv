module DataRegisters
#(parameter DATA_WIDTH = 4)
(
    input logic clk, rstn, En,
    input logic  [DATA_WIDTH-1:0] In,
    output logic  [DATA_WIDTH-1:0] Out
    );
    
    always@(posedge clk, negedge rstn)

        if(!rstn)
            Out <= 0;
        else if (En)
            Out <= In;
        else
            Out <= Out;
endmodule
