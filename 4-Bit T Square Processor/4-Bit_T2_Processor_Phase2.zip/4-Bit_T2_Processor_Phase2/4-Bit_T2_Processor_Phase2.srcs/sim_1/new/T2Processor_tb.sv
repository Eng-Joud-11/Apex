`timescale 1ns / 1ps

module T2Processor_tb;

    logic clk;
    logic rstn;

    T2Processor #(
        .FILE_NAME("machine_code.mem")
    ) dut (
        .clk(clk),
        .rstn(rstn)
    );

    initial begin
        rstn = 0;
        clk  = 0;
        #2 rstn = 1;
    end

    always #5 clk = ~clk;

    initial begin
        #1000 $finish;   
    end

endmodule