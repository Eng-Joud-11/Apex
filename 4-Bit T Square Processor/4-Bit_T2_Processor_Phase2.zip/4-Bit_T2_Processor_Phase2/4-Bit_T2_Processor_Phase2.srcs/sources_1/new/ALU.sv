module ALU
#(parameter DATA_WIDTH = 4)
(
    input logic [DATA_WIDTH-1:0] A,B,
    input logic S,
    output logic [DATA_WIDTH-1:0] Out,
    output logic CarryOut,Zero 
    );
    
    assign {CarryOut, Out} = (A + (B ^ {DATA_WIDTH{S}}) + S);
    assign Zero = (Out == '0);
    
endmodule
