module Decoder2to4(
    input logic D0,D1,
    output logic Y0, Y1, Y2, Y3
    );
    
    assign Y0 = (~D1) & (~D0);
    assign Y1 = (~D1) &  D0;
    assign Y2 =    D1 & (~D0);
    assign Y3 =    D1 &  D0 ;
    
endmodule
