module ProgramCounter
#(parameter ADDR_WIDTH = 4)
(
    input  logic clk, rstn, Load, 
    input  logic [ADDR_WIDTH-1:0] D,
    output logic [ADDR_WIDTH-1:0] Q
);

    always_ff @(posedge clk or negedge rstn) begin

        if (!rstn)
            Q <= '0;
            
        else if (Load)
            Q <= D;
            
        else
            Q <= Q + 1'b1;
            
    end
endmodule