module MUX2to1
#(parameter DATA_WIDTH = 4)
(
        input logic [DATA_WIDTH-1:0] In0, In1,
        input logic Sel,
        output logic [DATA_WIDTH-1:0] Out
    );
    
    assign Out = Sel ? In1 : In0;
endmodule
